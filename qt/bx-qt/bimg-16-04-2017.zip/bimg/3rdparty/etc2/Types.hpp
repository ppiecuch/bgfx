#ifndef __DARKRL__TYPES_HPP__
#define __DARKRL__TYPES_HPP__

// Platform definitions
#include "posh.h"

typedef posh_i8_t      int8;
typedef posh_u8_t     uint8;
typedef posh_i16_t     int16;
typedef posh_u16_t    uint16;
typedef posh_i32_t     int32;
typedef posh_u32_t    uint32;
typedef posh_i64_t     int64;
typedef posh_u64_t    uint64;

typedef unsigned int uint;

#endif
